uniform sampler2D wTex;
uniform vec2 wTexSize;
uniform int hp;
uniform int maxHp;

varying vec2 tCoord;

void main() {
    vec4 color = texture2D(wTex, tCoord);
    float hpNorm = float(hp)/float(maxHp);

    gl_FragColor = color * vec4(hpNorm, 1., hpNorm, 1.);
}