uniform sampler2D wTex;
uniform vec2 wTexSize;
uniform int oddT;

varying vec2 tCoord;

void main() {
    vec4 color = texture2D(wTex, tCoord);

    //gl_FragColor = color.brga;
    float pink_strength = abs(tCoord.x)-tCoord.y;
    vec4 pink_color = vec4(1., .75, .79, 1.) * vec4(vec3(pink_strength), 1.);
    gl_FragColor = pink_color + color;
}