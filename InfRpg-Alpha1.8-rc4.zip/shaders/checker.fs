uniform sampler2D wTex;
uniform int off;

varying vec2 tCoord;

float generate_color(vec2 pixel_pos) {
    int seed = int(pixel_pos.x*pixel_pos.y*43)+off;
    return float(int(float(seed)*26+12)%11)/10;
}

vec4 gen_full_color(vec2 pixel_pos) {
    float gr = generate_color(pixel_pos);
    float gg = generate_color(pixel_pos+vec2(4., 0.));
    float gb = generate_color(pixel_pos+vec2(3., 2.));
    return vec4(gr, gg, gb, 1.);
}

void main() {
    vec4 color = texture2D(wTex, tCoord);
    float alive = .95+sin(tCoord.y*5-(float(off)/10.));
    if (int(gl_FragCoord.x)%2 == 0 || int(gl_FragCoord.y)%2 == 0) {
        gl_FragColor = vec4(vec3(0.), 1.);
    }
    else {
        //gl_FragColor = color * vec4(tCoord, tCoord.y, 1.);
        gl_FragColor = color;
        if (alive < 0.) {
            float nr = gl_FragCoord.x;
            gl_FragColor = gen_full_color(gl_FragCoord);
        }
    }
}