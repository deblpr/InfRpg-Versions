varying vec2 tCoord;
void main() {
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
    tCoord = gl_MultiTexCoord0.xy;
}