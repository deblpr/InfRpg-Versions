#version 120

uniform sampler2D wTex;
uniform sampler2D lTex;
uniform sampler2D mask;
uniform float darkness;
uniform int battle_mode;

varying vec2 tCoord;

void battle_trans() {
    vec4 color = gl_FragColor;

    if (battle_mode == 1) {
        color *= vec4(.5, .5, 1., color.a);
    }

    gl_FragColor = color - vec4(vec3(darkness), color.a);
}

void main() {
    vec4 color = texture2D(wTex, tCoord);
    vec4 light_color = texture2D(lTex, tCoord);
    vec4 mcolor = texture2D(mask, tCoord);

    //float blurt1 = .035;
    float blurt1 = .023;
    float blurmult = .11;

    vec4 flight = light_color*0.2;
    // non-diagonal
    flight += texture2D(lTex, tCoord + vec2(blurt1, 0.))*blurmult;
    flight += texture2D(lTex, tCoord + vec2(-blurt1, 0.))*blurmult;
    flight += texture2D(lTex, tCoord + vec2(0., blurt1))*blurmult;
    flight += texture2D(lTex, tCoord + vec2(0., -blurt1))*blurmult;

    // diagonal
    flight += texture2D(lTex, tCoord + vec2(-blurt1, -blurt1))*blurmult;
    flight += texture2D(lTex, tCoord + vec2(-blurt1, blurt1))*blurmult;
    flight += texture2D(lTex, tCoord + vec2(blurt1, -blurt1))*blurmult;
    flight += texture2D(lTex, tCoord + vec2(blurt1, blurt1))*blurmult;

    gl_FragColor = color * flight;
    //gl_FragColor = flight;
    if (mcolor.r != 0 || mcolor.g != 0 || mcolor.b != 0) {
        gl_FragColor = color;
    }

    battle_trans();
}