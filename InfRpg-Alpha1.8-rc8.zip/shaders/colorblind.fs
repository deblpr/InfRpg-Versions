uniform sampler2D wTex;

varying vec2 tCoord;

void main() {
    vec4 color = texture2D(wTex, tCoord);
    vec3 color3 = vec3(color.xyz);
    vec3 color2 = vec3(0.3, 0.59, 0.11);

    gl_FragColor = dot(color3, color2);
}