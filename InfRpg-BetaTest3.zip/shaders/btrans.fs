#version 120

uniform sampler2D wTex;
uniform float darkness;
uniform int battle_mode;

varying vec2 tCoord;

void main() {
    vec4 color = texture2D(wTex, tCoord);

    if (battle_mode == 1) {
        color *= vec4(.5, .5, 1., 1.);
    }

    gl_FragColor = color - vec4(vec3(darkness), 1.);
}